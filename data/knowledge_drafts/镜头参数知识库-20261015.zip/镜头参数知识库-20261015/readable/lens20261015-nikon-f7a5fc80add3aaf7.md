# Nikon AF-S DX NIKKOR 18-140mm f/3.5-5.6G ED VR
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon F。
- 覆盖画幅：APS-C。
- 焦距起点(mm)：18。
- 焦距终点(mm)：140。
- 广角端最大光圈(f值)：3.5。
- 长焦端最大光圈(f值)：5.6。
- 最小光圈原文：f/22-38。
- 镜头光学防抖：支持。
- 自动对焦：支持。
- 前置滤镜直径(mm)：67。
- 单一条件重量(g)：490。
- 重量及条件原文：Approximately 490 g/17.3 oz。
- 最近对焦距离及条件原文：0.45 m/1.48 ft from focal plane。
- 最大放大倍率及条件原文：0.23x。
- 光学结构原文：17 elements in 12 groups (including one ED glass and one aspherical lens elements)。
- 光圈叶片数：7。
- 尺寸及条件原文：Approximately 78 x 97 mm/3.1 x 3.8 in.。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：变焦（整理生成）。

条件说明：以所列官网规格及原文条件为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/f-mount/zoom/normalzoom/af-s_dx_18-140mmf_35-56g_ed_vr/)

AI整理待审核；未经独立人工复核或真机测试。
