# Sigma 30mm F1.4 DC DN | Contemporary
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：L、Sony E、Fujifilm X、Nikon Z、Canon RF、Canon EF-M、Micro Four Thirds。
- 覆盖画幅：APS-C。
- 焦距起点(mm)：30。
- 焦距终点(mm)：30。
- 广角端最大光圈(f值)：1.4。
- 长焦端最大光圈(f值)：1.4。
- 最小光圈原文：F16。
- 镜头光学防抖：未核验。
- 自动对焦：支持。
- 前置滤镜直径(mm)：52。
- 单一条件重量(g)：未核验。
- 重量及条件原文：L-Mount:280g / 9.9oz. Canon EF-M mount:270g / 9.5oz. Canon RF Mount:285g / 10.1oz. FUJIFILM X Mount:275g / 9.7oz. Micro Four Thirds mount:260g / 9.2oz. Nikon Z mount:285g / 10.1oz. Sony E-mount:265g / 9.3oz.。
- 最近对焦距离及条件原文：30cm / 11.8in.。
- 最大放大倍率及条件原文：1:7。
- 光学结构原文：9 elements in 7 groups。
- 光圈叶片数：9。
- 尺寸及条件原文：L-Mount:φ65.4mm × 71.3mm / φ2.6in. × 2.8in. Canon EF-M mount:φ64.8mm × 73.3mm / φ2.6in. × 2.9in. Canon RF Mount:φ69.0mm × 71.3mm / φ2.7in. × 2.8in. FUJIFILM X Mount:φ64.8mm × 73.6mm / φ2.6in. × 2.9in. Micro Four Thirds mount:φ64.8mm × 72.1mm / φ2.6in. × 2.8in. Nikon Z mount:φ70.0mm × 75.3mm / φ2.8in. × 3.0in. Sony E-mount:φ64.8mm × 73.3mm / φ2.6in. × 2.9in. *The length of a lens is measured from the filter surface to its mount.。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：定焦（整理生成）。

条件说明：重量包含卡口或附件等条件，未压缩成单一克数。 多卡口产品；重量、长度及可用功能可能不同，以本卡保留的条件文字为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Sigma 官方规格](https://www.sigma-global.com/en/lenses/c016_30_14/)

AI整理待审核；未经独立人工复核或真机测试。
