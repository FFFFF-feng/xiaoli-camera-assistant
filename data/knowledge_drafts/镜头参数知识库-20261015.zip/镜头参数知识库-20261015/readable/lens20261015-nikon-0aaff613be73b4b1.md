# Nikon NIKKOR Z 24-70mm f/2.8 S II
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon Z。
- 覆盖画幅：全画幅。
- 焦距起点(mm)：24。
- 焦距终点(mm)：70。
- 广角端最大光圈(f值)：2.8。
- 长焦端最大光圈(f值)：2.8。
- 最小光圈原文：f/22。
- 镜头光学防抖：未核验。
- 自动对焦：未核验。
- 前置滤镜直径(mm)：77。
- 单一条件重量(g)：675。
- 重量及条件原文：Approximately 675 g/1 lb 7.9 oz。
- 最近对焦距离及条件原文：0.24 m/0.79 ft (at 24 mm and 28 mm), 0.27 m/0.89 ft (at 35 mm), 0.30 m/0.99 ft (at 50 mm), and 0.33 m/1.09 ft (at 70 mm) from focal plane。
- 最大放大倍率及条件原文：0.32x (70 mm focal length)。
- 光学结构原文：14 elements in 10 groups (including 2 ED glass elements, 3 aspherical lens elements, elements with Meso Amorphous Coat and ARNEO Coat, and a fluorine-coated front lens element)。
- 光圈叶片数：11。
- 尺寸及条件原文：Approximately 84 mm/3.4 in. maximum diameter x 142 mm/5.6 in. (distance to end of lens from camera lens mount flange)。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：变焦（整理生成）。

条件说明：以所列官网规格及原文条件为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/z-mount/z_24-70mmf28s2/)

AI整理待审核；未经独立人工复核或真机测试。
