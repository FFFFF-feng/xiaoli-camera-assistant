# Nikon NIKKOR Z DX 50-250mm f/4.5-6.3 VR
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon Z。
- 覆盖画幅：APS-C。
- 焦距起点(mm)：50。
- 焦距终点(mm)：250。
- 广角端最大光圈(f值)：4.5。
- 长焦端最大光圈(f值)：6.3。
- 最小光圈原文：f/22-32。
- 镜头光学防抖：支持。
- 自动对焦：未核验。
- 前置滤镜直径(mm)：62。
- 单一条件重量(g)：405。
- 重量及条件原文：Approximately 405 g/14.3 oz。
- 最近对焦距离及条件原文：0.5 m/1.64 ft (at 50 mm) from focal plane。
- 最大放大倍率及条件原文：0.23x。
- 光学结构原文：16 elements in 12 groups (including 1 ED glass element)。
- 光圈叶片数：7。
- 尺寸及条件原文：Approximately 74 mm/3 in. maximum diameter x 110 mm/4.4 in. (distance from camera lens mount flange)。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：变焦（整理生成）。

条件说明：以所列官网规格及原文条件为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/z-mount/z_dx_50-250mmf45-63_vr/)

AI整理待审核；未经独立人工复核或真机测试。
