# Sigma 18-50mm F2.8 DC DN | Contemporary
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：L、Sony E、Fujifilm X、Canon RF。
- 覆盖画幅：APS-C。
- 焦距起点(mm)：18。
- 焦距终点(mm)：50。
- 广角端最大光圈(f值)：2.8。
- 长焦端最大光圈(f值)：2.8。
- 最小光圈原文：F22。
- 镜头光学防抖：未核验。
- 自动对焦：支持。
- 前置滤镜直径(mm)：55。
- 单一条件重量(g)：未核验。
- 重量及条件原文：L-Mount:290g / 10.2oz. Canon RF Mount:300g / 10.6oz. FUJIFILM X Mount:285g / 10.1oz. Sony E-mount:290g / 10.2oz.。
- 最近对焦距离及条件原文：12.1(W)-30(T)cm / 4.8(W)-11.9(T)in.。
- 最大放大倍率及条件原文：1:2.8(W)-1:5(T)。
- 光学结构原文：10 groups, 13 elements (1 SLD and 3 aspherical lenses)。
- 光圈叶片数：7。
- 尺寸及条件原文：L-Mount:φ65.4mm × 74.5mm / φ2.6in. × 2.9in. Canon RF Mount:φ69.2mm × 74.5mm / φ2.7in. × 2.9in. FUJIFILM X Mount:φ61.6mm × 76.8mm / φ2.4in. × 3.0in. Sony E-mount:φ61.6mm × 76.5mm / φ2.4in. × 3.0in. *The length of a lens is measured from the filter surface to its mount.。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：变焦（整理生成）。

条件说明：重量包含卡口或附件等条件，未压缩成单一克数。 多卡口产品；重量、长度及可用功能可能不同，以本卡保留的条件文字为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Sigma 官方规格](https://www.sigma-global.com/en/lenses/c021_18_50_28/)

AI整理待审核；未经独立人工复核或真机测试。
