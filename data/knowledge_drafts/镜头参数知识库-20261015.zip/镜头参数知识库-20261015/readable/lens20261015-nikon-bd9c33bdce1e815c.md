# Nikon AF-S NIKKOR 600mm f/4E FL ED VR
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon F。
- 覆盖画幅：全画幅。
- 焦距起点(mm)：600。
- 焦距终点(mm)：600。
- 广角端最大光圈(f值)：4。
- 长焦端最大光圈(f值)：4。
- 最小光圈原文：f/22。
- 镜头光学防抖：支持。
- 自动对焦：支持。
- 前置滤镜直径(mm)：40.5。
- 单一条件重量(g)：3810。
- 重量及条件原文：Approximately 3810 g/8 lb 6.4 oz。
- 最近对焦距离及条件原文：4.4 m/14.4 ft from focal plane。
- 最大放大倍率及条件原文：0.14x。
- 光学结构原文：16 elements in 12 groups (including four ED glass and two fluorite lens elements, and lens elements with Nano Crystal Coat) and one meniscus protective glass element with fluorine coat。
- 光圈叶片数：9。
- 尺寸及条件原文：Approximately 166 mm maximum diameter x 432 mm (distance from camera lens mount flange)。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：定焦（整理生成）。

条件说明：以所列官网规格及原文条件为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/f-mount/singlefocal/telephoto/af-s_600mmf_4e_fl_ed_vr/)

AI整理待审核；未经独立人工复核或真机测试。
