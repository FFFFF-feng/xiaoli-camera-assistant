# Nikon AF-S NIKKOR 800mm f/5.6E FL ED VR
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon F。
- 覆盖画幅：未核验。
- 焦距起点(mm)：800。
- 焦距终点(mm)：800。
- 广角端最大光圈(f值)：5.6。
- 长焦端最大光圈(f值)：5.6。
- 最小光圈原文：f/32。
- 镜头光学防抖：支持。
- 自动对焦：支持。
- 前置滤镜直径(mm)：52。
- 单一条件重量(g)：4590。
- 重量及条件原文：Approximately 4590 g/10.1 lb。
- 最近对焦距离及条件原文：5.9 m/19.36 ft from focal plane (5.8 m/19.03 ft in MF)。
- 最大放大倍率及条件原文：1/6.6x (1/6.4x in MF)。
- 光学结构原文：20 elements in 13 groups (including two fluorite and two ED glass elements, and elements with Nano Crystal Coat) and one protective glass element。
- 光圈叶片数：9。
- 尺寸及条件原文：Approximately 160 x 461 mm/6.3 x 18.2 in.。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：定焦（整理生成）。

条件说明：画幅未标准化核验，保留为空；不得解释为不能用于全画幅。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/f-mount/singlefocal/telephoto/af-s_800mmf_56g_fl_ed_vr/)

AI整理待审核；未经独立人工复核或真机测试。
