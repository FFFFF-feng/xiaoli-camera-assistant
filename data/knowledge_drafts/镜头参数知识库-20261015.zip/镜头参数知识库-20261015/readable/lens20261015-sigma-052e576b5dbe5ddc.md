# Sigma 100-400mm F5-6.3 DG DN OS | Contemporary
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：L、Sony E、Fujifilm X。
- 覆盖画幅：全画幅。
- 焦距起点(mm)：100。
- 焦距终点(mm)：400。
- 广角端最大光圈(f值)：5。
- 长焦端最大光圈(f值)：6.3。
- 最小光圈原文：F22 - 29。
- 镜头光学防抖：支持。
- 自动对焦：未核验。
- 前置滤镜直径(mm)：67。
- 单一条件重量(g)：未核验。
- 重量及条件原文：L-Mount:1,135g / 40.0oz. (PROTECTIVE COVER PT-31 included) FUJIFILM X Mount:1,135g / 40.0oz. (PROTECTIVE COVER PT-31 included) Sony E-mount:1,140g / 40.2oz. (PROTECTIVE COVER PT-31 included)。
- 最近对焦距离及条件原文：112(W) - 160(T)cm。
- 最大放大倍率及条件原文：1:4.1(400mm)。
- 光学结构原文：22elements in 16 groups。
- 光圈叶片数：9。
- 尺寸及条件原文：L-Mount:φ86.0mm x 197.2mm / φ3.4in. x 7.8in. FUJIFILM X Mount:φ86.0mm × 199.5mm / φ3.4in. × 7.9in. Sony E-mount:φ86.0mm x 199.2mm / φ3.4in. x 7.8in. *The length of a lens is measured from the filter surface to its mount.。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：变焦（整理生成）。

条件说明：重量包含卡口或附件等条件，未压缩成单一克数。 多卡口产品；重量、长度及可用功能可能不同，以本卡保留的条件文字为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Sigma 官方规格](https://www.sigma-global.com/en/lenses/c020_100_400_5_63/)

AI整理待审核；未经独立人工复核或真机测试。
