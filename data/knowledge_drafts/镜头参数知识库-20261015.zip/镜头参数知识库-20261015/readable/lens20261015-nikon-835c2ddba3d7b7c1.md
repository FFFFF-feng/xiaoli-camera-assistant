# Nikon NIKKOR Z 40mm f/2 (SE)
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon Z。
- 覆盖画幅：全画幅。
- 焦距起点(mm)：40。
- 焦距终点(mm)：40。
- 广角端最大光圈(f值)：2。
- 长焦端最大光圈(f值)：2。
- 最小光圈原文：f/16。
- 镜头光学防抖：未核验。
- 自动对焦：未核验。
- 前置滤镜直径(mm)：52。
- 单一条件重量(g)：170。
- 重量及条件原文：Approximately 170 g/6 oz。
- 最近对焦距离及条件原文：0.29 m/0.96 ft from focal plane。
- 最大放大倍率及条件原文：0.17x。
- 光学结构原文：6 elements in 4 groups (including 2 aspherical lens elements)。
- 光圈叶片数：9。
- 尺寸及条件原文：Approximately 71.5 mm/2.9 in. maximum diameter x 45.5 mm/1.8 in. (distance from camera lens mount flange)。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：定焦（整理生成）。

条件说明：以所列官网规格及原文条件为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/z-mount/z_40mmf2_se/)

AI整理待审核；未经独立人工复核或真机测试。
