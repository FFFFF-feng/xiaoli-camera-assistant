# Nikon NIKKOR Z 20mm f/1.8 S
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon Z。
- 覆盖画幅：全画幅。
- 焦距起点(mm)：20。
- 焦距终点(mm)：20。
- 广角端最大光圈(f值)：1.8。
- 长焦端最大光圈(f值)：1.8。
- 最小光圈原文：f/16。
- 镜头光学防抖：未核验。
- 自动对焦：未核验。
- 前置滤镜直径(mm)：77。
- 单一条件重量(g)：505。
- 重量及条件原文：Approximately 505 g/1 lb 1.9 oz。
- 最近对焦距离及条件原文：0.20 m/0.66 ft from focal plane。
- 最大放大倍率及条件原文：0.19x。
- 光学结构原文：14 elements in 11 groups (including 3 ED glass and 3 aspherical lens elements, and elements with Nano Crystal Coat)。
- 光圈叶片数：9。
- 尺寸及条件原文：Approximately 84.5 mm/3.4 in. maximum diameter x 108.5 mm/4.3 in. (distance from camera lens mount flange)。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：定焦（整理生成）。

条件说明：以所列官网规格及原文条件为准。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/z-mount/z_20mmf18s/)

AI整理待审核；未经独立人工复核或真机测试。
