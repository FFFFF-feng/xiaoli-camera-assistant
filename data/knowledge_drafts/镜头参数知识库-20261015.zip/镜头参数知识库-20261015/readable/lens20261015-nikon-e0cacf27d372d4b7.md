# Nikon NIKKOR Z 100-400mm f/4.5-5.6 VR S
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon Z。
- 覆盖画幅：全画幅。
- 焦距起点(mm)：100。
- 焦距终点(mm)：400。
- 广角端最大光圈(f值)：4.5。
- 长焦端最大光圈(f值)：5.6。
- 最小光圈原文：f/32-40。
- 镜头光学防抖：支持。
- 自动对焦：支持。
- 前置滤镜直径(mm)：77。
- 单一条件重量(g)：未核验。
- 重量及条件原文：Approximately 1,435 g/3 lb 2.7 oz (with tripod collar); approximately 1,355 g/2 lb 15.8 oz (without tripod collar)。
- 最近对焦距离及条件原文：0.75 m/2.46 ft from the image sensor at the wide-angle end; 0.98 m/3.22 ft at the telephoto end。
- 最大放大倍率及条件原文：0.38x。
- 光学结构原文：25 elements in 20 groups (including 6 ED glass and 2 Super ED glass elements, elements with Nano Crystal Coat and ARNEO Coat, and a fluorine-coated front lens element)。
- 光圈叶片数：9。
- 尺寸及条件原文：Approximately 98 mm/3.9 in. maximum diameter x 222 mm/8.8 in. (distance from camera lens mount flange)。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：变焦（整理生成）。

条件说明：重量包含卡口或附件等条件，未压缩成单一克数。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/z-mount/z_100-400mmf45-56_vr_s/)

AI整理待审核；未经独立人工复核或真机测试。
