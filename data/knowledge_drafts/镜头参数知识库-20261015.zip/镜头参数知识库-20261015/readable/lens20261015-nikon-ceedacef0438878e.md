# Nikon NIKKOR Z 600mm f/6.3 VR S
核验日期：2026-10-15。来源地区：全球英文站。

- 原生卡口：Nikon Z。
- 覆盖画幅：全画幅。
- 焦距起点(mm)：600。
- 焦距终点(mm)：600。
- 广角端最大光圈(f值)：6.3。
- 长焦端最大光圈(f值)：6.3。
- 最小光圈原文：f/32。
- 镜头光学防抖：支持。
- 自动对焦：未核验。
- 前置滤镜直径(mm)：95。
- 单一条件重量(g)：未核验。
- 重量及条件原文：Approximately 1,470 g/3 lb 3.9 oz (with tripod collar); approximately 1,390 g/3 lb 1.1 oz (without tripod collar)。
- 最近对焦距离及条件原文：4 m/13.13 ft from focal plane。
- 最大放大倍率及条件原文：0.15x。
- 光学结构原文：21 elements in 14 groups (including 2 ED elements, 1 SR element, 1 PF element, elements with Nano Crystal Coat, and a fluorine-coated front lens element)。
- 光圈叶片数：9。
- 尺寸及条件原文：Approximately 106.5 mm/4.2 in. maximum diameter x 278 mm/11 in. (distance to end of lens from camera lens mount flange)。
- 对焦驱动原文：未核验。

按已核验焦距区间分类：定焦（整理生成）。

条件说明：重量包含卡口或附件等条件，未压缩成单一克数。

使用边界：焦距为镜头实际焦距，不是35mm等效焦距。最大光圈两端数值不表示中间焦段的精确变化曲线，也不等于最小光圈。最近对焦距离通常从焦平面起算，不是镜头前端工作距离。防抖支持不等于机身协同级数；未核验不代表不支持。卡口相同不保证全部AF、连拍、视频或增距镜功能兼容。未提供实时价格、在售或停产断言。

来源：[Nikon 官方规格](https://imaging.nikon.com/imaging/lineup/lens/z-mount/z_600mmf63_vr_s/)

AI整理待审核；未经独立人工复核或真机测试。
